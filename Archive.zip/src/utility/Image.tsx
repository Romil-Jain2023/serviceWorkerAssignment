export type ImageProps = {
    image: string;
};